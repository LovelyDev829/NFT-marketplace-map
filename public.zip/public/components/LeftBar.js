import React from 'react'
import './LeftBar.css'
import { useDispatch, useSelector } from 'react-redux';

function LeftBar() {
    const sideBarFlag = useSelector(state => state.sideBarFlag)
    return (
        <div className={ sideBarFlag ? 'LeftBar slide-right' : 'LeftBar'}>
            
        </div>
    )
}

export default LeftBar