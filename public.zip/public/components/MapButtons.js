import React from 'react'
import 'animate.css'
import './MapButtons.css'
import { maxZoomOutFlagChange, sideBtnClicked, plusBtnClicked, minusBtnClicked } from '../actions/index';
import { useDispatch, useSelector } from 'react-redux';

function MapButtons() {
    const sideBarFlag = useSelector(state => state.sideBarFlag)
    const dispatch = useDispatch()
    const sideBtnClickeD = () => {
        dispatch(sideBtnClicked());
        dispatch(maxZoomOutFlagChange());
    }
    const plusBtnClickeD = () => {
        dispatch(plusBtnClicked());
        dispatch(maxZoomOutFlagChange());
    }
    const minusBtnClickeD = () => {
        dispatch(minusBtnClicked());
        dispatch(maxZoomOutFlagChange());
    }
    return (
        <div className='MapButtons'>
            <div className={ sideBarFlag ? 'map-button slide-right' : 'map-button'} onClick={sideBtnClickeD}>
                <svg width="23" height="15" viewBox="0 0 23 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4.92695 6.15488H18.427V8.85488H4.92695V6.15488ZM0.876953 0.754883H22.477V3.45488H0.876953V0.754883ZM8.97695 11.5549H14.377V14.2549H8.97695V11.5549Z" fill="#AAAAAA" />
                </svg>
            </div>
            <div className={ sideBarFlag ? 'map-button slide-right' : 'map-button'} onClick={plusBtnClickeD}>
                <svg width="17" height="4" viewBox="0 0 17 4" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0.664062 0.955566H16.6899V3.74266H0.664062V0.955566Z" fill="#AAAAAA" />
                </svg>
                <svg width="4" height="17" viewBox="0 0 4 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3.07031 0.335938L3.07031 16.3617L0.283215 16.3617L0.283216 0.335937L3.07031 0.335938Z" fill="#AAAAAA" />
                </svg>
            </div>
            <div className={ sideBarFlag ? 'map-button slide-right' : 'map-button'} onClick={minusBtnClickeD}>
                <svg width="17" height="4" viewBox="0 0 17 4" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0.664062 0.277344H16.6899V3.06444H0.664062V0.277344Z" fill="#4D4E4D" fillOpacity="0.5" />
                </svg>

            </div>
        </div>
    )
}

export default MapButtons